export interface Message {
    id: number;
    type: string;
    data: any;
}
