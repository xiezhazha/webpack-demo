import { XCUITestDriver } from './build/lib/driver';
import { startServer } from './build/lib/server';

export { XCUITestDriver, startServer };
export default XCUITestDriver;
