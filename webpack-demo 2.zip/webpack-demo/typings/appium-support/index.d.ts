import * as timing from './build/lib/timing';

export { timing };

// export default { Timer };
