import * as express from 'express';
import * as http from 'http';
import * as WebSocket from 'websocket';
import * as adbkit from 'adbkit';
import * as scrcpy from 'scrcpy-server';

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.server({ httpServer: server });

// 初始化 ADB 客户端
const client = adbkit.createClient();

// 存储已连接的 WebSocket 客户端
const clients: WebSocket.connection[] = [];

// 监听 WebSocket 连接事件
wss.on('request', (req) => {
    let connection: WebSocket.connection | null = req.accept(null, req.origin);
    
    connection.once('close', () => {
        clients.splice(clients.indexOf(connection!), 1);
        connection = null;
        console.log('WebSocket connection closed.');
    });

    clients.push(connection!);
});

// 获取安卓设备的视频流并转发给 WebSocket 客户端
async function startVideoStream(deviceId: string): Promise<void> {
    // 获取指定设备的信息
    const device = await client.device(deviceId);

    // 配置 scrcpy 参数
    const options = {
        bitrate: 2 * 1024 * 1024, // 比特率设置为 2 Mbps
        maxFps: 30,               // 最大帧率为 30 FPS
        encoder: 'h264',          // 编码器设置为 H.264
        width: 720,               // 视频宽度
        height: 1280              // 视频高度
    };

    // 开始接收视频流
    device.stream(options).on('data', (chunk) => {
        for (const client of clients) {
            client.sendBytes(chunk); // 将视频数据发送给每个客户端
        }
    }).on('end', () => {
        console.log('Video stream ended.');
        clients.forEach(client => client.close());
    }).on('error', (err) => {
        console.error('Error in video stream:', err);
        clients.forEach(client => client.close());
    });
}

// 主函数入口
(async () => {
    try {
        // 获取连接的所有设备列表
        const devices = await client.devices();

        if (devices.length === 0) {
            throw new Error('No connected devices found.');
        }

        // 假设只有一个设备连接
        const deviceId = devices[0].id;

        // 启动视频流
        await startVideoStream(deviceId);

        // 启动 HTTP 服务器并监听 WebSocket 请求
        server.listen(3000, () => {
            console.log('Server listening on port 3000');
        });

        // 监听 SIGINT 和 SIGTERM 信号，优雅关闭服务
        process.on('SIGINT', () => {
            console.log('\nReceived SIGINT. Shutting down...');
            clients.forEach(client => client.close());
            process.exit(0);
        });

        process.on('SIGTERM', () => {
            console.log('\nReceived SIGTERM. Shutting down...');
            clients.forEach(client => client.close());
            process.exit(0);
        });

    } catch (error) {
        console.error('Error initializing video stream:', error);
        process.exit(1);
    }
})();