import { ParamsBase } from './ParamsBase';

export interface ParamsStream extends ParamsBase {
    udid: string;
    player: string;
}
