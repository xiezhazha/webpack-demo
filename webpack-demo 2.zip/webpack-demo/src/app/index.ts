import "../style/app.css";
import { StreamClientScrcpy } from "./googDevice/client/StreamClientScrcpy";
import { ParamsStreamScrcpy } from "../types/ParamsStreamScrcpy";
import { MsePlayer } from "./player/MsePlayer";
import KeyEvent from "./googDevice/android/KeyEvent";
import { KeyCodeControlMessage } from "./controlMessage/KeyCodeControlMessage";
import SvgImage from './ui/SvgImage';
import { ToolBoxButton } from './toolbox/ToolBoxButton';
import {get} from 'lodash';
// import { BasePlayer } from './player/BasePlayer';

window.onload = async function () {
  // const hash = location.hash.replace(/^#!/, "");
  // const parsedQuery = new URLSearchParams(hash);
  // // const action = parsedQuery.get('action');
  // const ws = parsedQuery.get("ws");
  // console.log(ws, "ws");
  // const params = {
  //   action: "stream",
  //   player: "mse",
  //   udid: "0.0.0.0:0",
  //   // udid: "8.138.149.57:20460",
  //   ws: "wss://8.149.245.163:1717/",
  //   // ws: "ws://39.105.25.249:9473/?action=proxy-adb&remote=tcp%3A8886&udid=8.134.158.159%3A16392",
  // } as ParamsStreamScrcpy;

  const params = {
    action: "stream",
    player: "mse",
    udid: "c85708280612",
    ws: "ws://127.0.0.1:8000/?action=proxy-adb&remote=tcp%3A8886&udid=c85708280612",
    // ws:"wss://bws.alibaba.net/api/v1.0/sessions/ce4e23778370428cadf33093cc6b58ec",
  }as ParamsStreamScrcpy;
  StreamClientScrcpy.registerPlayer(MsePlayer);
  const dom = document.getElementById("scrcpy") as HTMLElement;
  const streamClient = StreamClientScrcpy.start(dom, params);
  const ws = get(streamClient, 'streamReceiver.ws') as unknown as WebSocket;

  let wsInterval: undefined | ReturnType<typeof setInterval>;
  
  ws.addEventListener('open', () => {
    //每隔五秒发送一个ping
    wsInterval = setInterval(() => {
      ws.send('ping')
    }, 5000);
    // setInterval(() => {
    //   ws.send('ping')
    // }, 5000);
    console.log('ws.onOpen');
  });

  ws.addEventListener('close', () => {
    wsInterval && clearInterval(wsInterval);
    console.log('ws.close');
  });

  
  // ws.onOpen(() => {
  //   console.log('ws.onOpen');
  // })
  // console.log
  console.log(streamClient,ws,'lllll')
  // const player = BasePlayer.getPlayer(params.player);
  // const player =  new BasePlayer(MsePlayer);
  const list = [
    { title: "Power", code: 26, icon: 3 },
    { title: "Volume up", code: 24, icon: 4 },
    { title: "Volume down", code: 25, icon: 5 },
    { title: "Back", code: 4, icon: 0 },
    { title: "Home", code: 3, icon: 1 },
    { title: "Overview", code: 187, icon: 2 },
  ];

  function handleControlButtonEvent(event: MouseEvent, element: HTMLElement) {
    const action =
      event.type === "mousedown" ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP;
    const title = element.getAttribute("title");
    console.log(title, "title");
    if (title === "Take screenshot") {
      // streamClient.createScreenshot(streamClient.getDeviceName());
      const screenshot = new ToolBoxButton('Take screenshot', SvgImage.Icon.CAMERA);
      screenshot.addEventListener('click', () => {
        // player.createScreenshot(streamClient.getDeviceName());
        console.log(streamClient.getDeviceName());
        console.log('streamClient.getDeviceName()');
      });
    }
    const code = list.find((item) => item.title === title)?.code as number;
    console.log(code, "code");
    const keyCodeControlMessage = new KeyCodeControlMessage(action, code, 0, 0);
    streamClient.sendMessage(keyCodeControlMessage);
  }

  // 创建控制处理器实例
  const controlElements = document.querySelectorAll<HTMLElement>(".control");
  controlElements.forEach((element) => {
    element.addEventListener("mousedown", (e) =>
      handleControlButtonEvent(e, element)
    );
    element.addEventListener("mouseup", (e) =>
      handleControlButtonEvent(e, element)
    );
  });

  // document.querySelector(".control1")?.addEventListener(
  //   "click",
  //   () => {
  //     // console.log(e, "e", this);
  //     // const a = document.querySelector(".control1").getElement();
  //     const checkbox = document.getElementById(
  //       "input_capture_keyboard_0.0.0.0:0_H264 Converter"
  //     );
  //     streamClient.setHandleKeyboardEvents(checkbox?.checked);
  //   }
  //   // handleControlButtonEvent(e, element)
  // );

  return;
};
