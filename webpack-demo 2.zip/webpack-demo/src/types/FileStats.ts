export interface FileStats {
    name: string;
    isDir: number;
    size: number;
    dateModified: number;
}
