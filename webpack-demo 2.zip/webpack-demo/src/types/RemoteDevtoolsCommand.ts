export enum RemoteDevtoolsCommand {
    LIST_DEVTOOLS = 'list_devtools',
}
