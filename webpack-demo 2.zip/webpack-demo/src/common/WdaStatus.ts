export enum WdaStatus {
    STARTING = 'STARTING',
    STARTED = 'STARTED',
    STOPPED = 'STOPPED',
}
