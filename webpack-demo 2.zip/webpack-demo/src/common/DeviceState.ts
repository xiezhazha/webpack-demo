export enum DeviceState {
    DEVICE = 'device',
    DISCONNECTED = 'disconnected',

    CONNECTED = 'Connected',
}
