import { Message } from './Message';

export interface MessageFileListing extends Message {
    entry: string;
}
