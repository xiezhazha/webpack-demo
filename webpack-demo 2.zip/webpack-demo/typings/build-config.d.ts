declare var __PATHNAME__: string;
