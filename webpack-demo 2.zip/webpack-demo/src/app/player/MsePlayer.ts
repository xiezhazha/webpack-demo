/**
 * 导入基础播放器类和其他必要的模块
 */
import { BasePlayer } from "./BasePlayer";
import VideoConverter, { setLogger, mimeType } from "h264-converter";
import VideoSettings from "../VideoSettings";
import Size from "../Size";
import { DisplayInfo } from "../DisplayInfo";

// 定义视频质量统计接口
interface QualityStats {
  timestamp: number;
  decodedFrames: number;
  droppedFrames: number;
}

// 定义数据块类型
type Block = {
  start: number;
  end: number;
};

/**
 * MSE播放器实现类
 */
export class MsePlayer extends BasePlayer {
  public static readonly storageKeyPrefix = "MseDecoder"; // 存储键前缀
  public static readonly playerFullName = "H264 Converter"; // 播放器全称
  public static readonly playerCodeName = "mse"; // 播放器代码名称
  public static readonly preferredVideoSettings: VideoSettings =
    new VideoSettings({
      // 首选视频设置
      lockedVideoOrientation: -1,
      bitrate: 7340032,
      maxFps: 60,
      iFrameInterval: 10,
      bounds: new Size(720, 720),
      sendFrameMeta: false,
    });

  private static DEFAULT_FRAMES_PER_FRAGMENT = 1; // 默认片段帧数
  private static DEFAULT_FRAMES_PER_SECOND = 60; // 默认每秒帧数

  /**
   * 创建HTML视频元素
   * @param id 元素ID（可选）
   * @returns HTML视频元素实例
   */
  public static createElement(id?: string): HTMLVideoElement {
    const tag = document.createElement("video") as HTMLVideoElement;
    tag.muted = true;
    tag.autoplay = true;
    tag.setAttribute("muted", "muted");
    tag.setAttribute("autoplay", "autoplay");
    if (typeof id === "string") {
      tag.id = id;
    }
    tag.className = "video-layer";
    return tag;
  }

  private converter?: VideoConverter; // 视频转换器实例
  private videoStats: QualityStats[] = []; // 视频质量统计数据数组
  private noDecodedFramesSince = -1; // 自上次解码帧以来的时间戳
  private currentTimeNotChangedSince = -1; // 当前时间未改变的时间戳
  private bigBufferSince = -1; // 大缓冲区开始时间戳
  private aheadOfBufferSince = -1; // 超前于缓冲区开始时间戳
  public fpf: number = MsePlayer.DEFAULT_FRAMES_PER_FRAGMENT; // 帧每片段数量
  public readonly supportsScreenshot = true; // 支持截图标志
  private sourceBuffer?: SourceBuffer; // 源缓冲区对象
  private waitUntilSegmentRemoved = false; // 等待直到段被移除标志
  private blocks: Block[] = []; // 数据块数组
  private frames: Uint8Array[] = []; // 帧数组
  private jumpEnd = -1; // 跳转结束位置
  private lastTime = -1; // 上次时间记录
  protected canPlay = false; // 可播放标志
  private seekingSince = -1; // 开始寻找时间戳
  protected readonly isSafari = !!(window as unknown as any)["safari"]; // 是否为Safari浏览器
  protected readonly isChrome = navigator.userAgent.includes("Chrome"); // 是否为Chrome浏览器
  protected readonly isMac = navigator.platform.startsWith("Mac"); // 是否为Mac平台
  private MAX_TIME_TO_RECOVER = 200; // 最大恢复时间（毫秒）
  private MAX_BUFFER = this.isSafari
    ? 2
    : this.isChrome && this.isMac
    ? 0.9
    : 0.2; // 最大缓冲量
  private MAX_AHEAD = -0.2; // 最大超前值

  /**
   * 判断是否支持当前媒体源类型
   * @returns 返回是否支持
   */
  public static isSupported(): boolean {
    return (
      typeof MediaSource !== "undefined" &&
      MediaSource.isTypeSupported(mimeType)
    );
  }

  /**
   * 构造函数初始化
   * @param udid 设备唯一标识符
   * @param displayInfo 显示信息（可选）
   * @param name 播放器名称，默认为playerFullName
   * @param tag 视频标签元素
   */
  constructor(
    udid: string,
    displayInfo?: DisplayInfo,
    name = MsePlayer.playerFullName,
    protected tag: HTMLVideoElement = MsePlayer.createElement()
  ) {
    super(udid, displayInfo, name, MsePlayer.storageKeyPrefix, tag);
    tag.oncontextmenu = function (event: MouseEvent): boolean {
      event.preventDefault();
      return false;
    };
    tag.addEventListener("error", this.onVideoError);
    tag.addEventListener("canplay", this.onVideoCanPlay);
    setLogger(() => {}, console.error);
  }

  // 视频错误事件处理方法
  onVideoError = (event: Event): void => {
    console.error(`[${this.name}]`, event);
  };

  // 视频可以播放事件处理方法
  onVideoCanPlay = (): void => {
    this.onCanPlayHandler();
  };

  // 创建视频转换器实例
  private static createConverter(
    tag: HTMLVideoElement,
    fps: number = MsePlayer.DEFAULT_FRAMES_PER_SECOND,
    fpf: number = MsePlayer.DEFAULT_FRAMES_PER_FRAGMENT
  ): VideoConverter {
    return new VideoConverter(tag, fps, fpf);
  }

  // 获取视频播放质量统计
  private getVideoPlaybackQuality(): QualityStats | null {
    const video = this.tag as any;
    if (typeof video.mozDecodedFrames !== "undefined") {
      return null;
    }
    const now = Date.now();
    if (typeof this.tag.getVideoPlaybackQuality == "function") {
      const temp = this.tag.getVideoPlaybackQuality();
      return {
        timestamp: now,
        decodedFrames: temp.totalVideoFrames,
        droppedFrames: temp.droppedVideoFrames,
      };
    }

    if (typeof video.webkitDecodedFrameCount !== "undefined") {
      return {
        timestamp: now,
        decodedFrames: video.webkitDecodedFrameCount,
        droppedFrames: video.webkitDroppedFrameCount,
      };
    }
    return null;
  }

  // 可播放处理器
  protected onCanPlayHandler(): void {
    this.canPlay = true;
    this.tag.play();
    this.tag.removeEventListener("canplay", this.onVideoCanPlay);
    this.checkVideoResize();
  }

  // 计算动量统计
  protected calculateMomentumStats(): void {
    const stat = this.getVideoPlaybackQuality();
    if (!stat) {
      return;
    }

    const timestamp = Date.now();
    const oneSecondBefore = timestamp - 1000;
    this.videoStats.push(stat);

    while (
      this.videoStats.length &&
      this.videoStats[0].timestamp < oneSecondBefore
    ) {
      this.videoStats.shift();
    }
    while (
      this.inputBytes.length &&
      this.inputBytes[0].timestamp < oneSecondBefore
    ) {
      this.inputBytes.shift();
    }
    let inputBytes = 0;
    this.inputBytes.forEach((item) => {
      inputBytes += item.bytes;
    });
    const inputFrames = this.inputBytes.length;
    if (this.videoStats.length) {
      const oldest = this.videoStats[0];
      const decodedFrames = stat.decodedFrames - oldest.decodedFrames;
      const droppedFrames = stat.droppedFrames - oldest.droppedFrames;
      this.momentumQualityStats = {
        decodedFrames,
        droppedFrames,
        inputBytes,
        inputFrames,
        timestamp,
      };
    }
  }

  // 重置统计信息
  protected resetStats(): void {
    super.resetStats();
    this.videoStats = [];
  }

  // 获取图像的数据URL
  public getImageDataURL(): string {
    const canvas = document.createElement("canvas");
    canvas.width = this.tag.clientWidth;
    canvas.height = this.tag.clientHeight;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.drawImage(this.tag, 0, 0, canvas.width, canvas.height);
    }

    return canvas.toDataURL();
  }

  // 播放视频
  public play(): void {
    super.play();
    if (this.getState() !== BasePlayer.STATE.PLAYING) {
      return;
    }
    if (!this.converter) {
      let fps = MsePlayer.DEFAULT_FRAMES_PER_SECOND;
      if (this.videoSettings) {
        fps = this.videoSettings.maxFps;
      }
      this.converter = MsePlayer.createConverter(this.tag, fps, this.fpf);
      this.canPlay = false;
      this.resetStats();
    }
    this.converter.play();
  }

  // 暂停视频
  public pause(): void {
    super.pause();
    this.stopConverter();
  }

  // 停止视频
  public stop(): void {
    super.stop();
    this.stopConverter();
  }

  // 设置视频设置
  public setVideoSettings(
    videoSettings: VideoSettings,
    fitToScreen: boolean,
    saveToStorage: boolean
  ): void {
    if (
      this.videoSettings &&
      this.videoSettings.maxFps !== videoSettings.maxFps
    ) {
      const state = this.getState();
      if (this.converter) {
        this.stop();
        this.converter = MsePlayer.createConverter(
          this.tag,
          videoSettings.maxFps,
          this.fpf
        );
        this.canPlay = false;
      }
      if (state === BasePlayer.STATE.PLAYING) {
        this.play();
      }
    }
    super.setVideoSettings(videoSettings, fitToScreen, saveToStorage);
  }

  // 获取首选视频设置
  public getPreferredVideoSetting(): VideoSettings {
    return MsePlayer.preferredVideoSettings;
  }

  // 检查视频尺寸变化
  checkVideoResize = (): void => {
    if (!this.tag) {
      return;
    }
    const { videoHeight, videoWidth } = this.tag;
    if (this.videoHeight !== videoHeight || this.videoWidth !== videoWidth) {
      this.calculateScreenInfoForBounds(videoWidth, videoHeight);
    }
  };

  // 清理源缓冲区
  cleanSourceBuffer = (): void => {
    if (!this.sourceBuffer) {
      return;
    }
    if (this.sourceBuffer.updating) {
      return;
    }
    if (this.blocks.length < 10) {
      return;
    }
    try {
      this.sourceBuffer.removeEventListener(
        "updateend",
        this.cleanSourceBuffer
      );
      this.waitUntilSegmentRemoved = false;
      const removeStart = this.blocks[0].start;
      const removeEnd = this.blocks[4].end;
      this.blocks = this.blocks.slice(5);
      this.sourceBuffer.remove(removeStart, removeEnd);
      let frame = this.frames.shift();
      while (frame) {
        if (!this.checkForIFrame(frame)) {
          this.frames.unshift(frame);
          break;
        }
        frame = this.frames.shift();
      }
    } catch (error: any) {
      console.error(`[${this.name}]`, "Failed to clean source buffer");
    }
  };

  // 跳转到末尾
  jumpToEnd = (): void => {
    if (!this.sourceBuffer) {
      return;
    }
    if (this.sourceBuffer.updating) {
      return;
    }
    if (!this.tag.buffered.length) {
      return;
    }
    const end = this.tag.buffered.end(this.tag.seekable.length - 1);
    console.log(
      `[${this.name}]`,
      `Jumping to the end (${this.jumpEnd}, ${end - this.jumpEnd}).`
    );
    this.tag.currentTime = end;
    this.jumpEnd = -1;
    this.sourceBuffer.removeEventListener("updateend", this.jumpToEnd);
  };

  // 推送一帧数据
  public pushFrame(frame: Uint8Array): void {
    super.pushFrame(frame);
    if (!this.checkForIFrame(frame)) {
      this.frames.push(frame);
    } else {
      this.checkForBadState();
    }
  }

  // 检查不良状态并采取措施
  protected checkForBadState(): void {
    const { currentTime } = this.tag;
    const now = Date.now();

    let hasReasonToJump = false;

    if (this.momentumQualityStats) {
      if (
        this.momentumQualityStats.decodedFrames === 0 &&
        this.momentumQualityStats.inputFrames > 0
      ) {
        if (this.noDecodedFramesSince === -1) {
          this.noDecodedFramesSince = now;
        } else {
          const time = now - this.noDecodedFramesSince;
          if (time > this.MAX_TIME_TO_RECOVER) {
            hasReasonToJump = true;
          }
        }
      } else {
        this.noDecodedFramesSince = -1;
      }
    }

    if (
      currentTime === this.lastTime &&
      this.currentTimeNotChangedSince === -1
    ) {
      this.currentTimeNotChangedSince = now;
    } else {
      this.currentTimeNotChangedSince = -1;
    }
    this.lastTime = currentTime;

    if (this.tag.buffered.length) {
      const end = this.tag.buffered.end(0);
      const buffered = end - currentTime;

      if ((end | 0) - currentTime > this.MAX_BUFFER) {
        if (this.bigBufferSince === -1) {
          this.bigBufferSince = now;
        } else {
          const time = now - this.bigBufferSince;
          if (time > this.MAX_TIME_TO_RECOVER) {
            hasReasonToJump = true;
          }
        }
      } else {
        this.bigBufferSince = -1;
      }

      if (buffered < this.MAX_AHEAD) {
        if (this.aheadOfBufferSince === -1) {
          this.aheadOfBufferSince = now;
        } else {
          const time = now - this.aheadOfBufferSince;
          if (time > this.MAX_TIME_TO_RECOVER) {
            hasReasonToJump = true;
          }
        }
      } else {
        this.aheadOfBufferSince = -1;
      }

      if (this.currentTimeNotChangedSince !== -1) {
        const time = now - this.currentTimeNotChangedSince;
        if (time > this.MAX_TIME_TO_RECOVER) {
          hasReasonToJump = true;
        }
      }

      if (!hasReasonToJump) {
        return;
      }

      let waitingForSeekEnd = 0;
      if (this.seekingSince !== -1) {
        waitingForSeekEnd = now - this.seekingSince;
        if (waitingForSeekEnd < 1500) {
          return;
        }
      }

      const onSeekEnd = () => {
        this.seekingSince = -1;
        this.tag.removeEventListener("seeked", onSeekEnd);
        this.tag.play();
      };

      if (this.seekingSince !== -1) {
        console.warn(
          `[${this.name}]`,
          `Attempt to seek while already seeking! ${waitingForSeekEnd}`
        );
      }
      this.seekingSince = now;
      this.tag.addEventListener("seeked", onSeekEnd);
      this.tag.currentTime = this.tag.buffered.end(0);
    }
  }

  // 检查是否包含I帧
  protected checkForIFrame(frame: Uint8Array): boolean {
    if (!this.converter) {
      return false;
    }
    this.sourceBuffer = this.converter.sourceBuffer;
    if (BasePlayer.isIFrame(frame)) {
      let start = 0;
      let end = 0;
      if (this.tag.buffered && this.tag.buffered.length) {
        start = this.tag.buffered.start(0);
        end = this.tag.buffered.end(0);
      }
      if (end !== 0 && start < end) {
        const block: Block = {
          start,
          end,
        };
        this.blocks.push(block);
        if (this.blocks.length > 10) {
          this.waitUntilSegmentRemoved = true;

          this.sourceBuffer.addEventListener(
            "updateend",
            this.cleanSourceBuffer
          );
          this.converter.appendRawData(frame);
          return true;
        }
      }
      if (this.sourceBuffer) {
        this.sourceBuffer.onupdateend = this.checkVideoResize;
      }
    }
    if (this.waitUntilSegmentRemoved) {
      return false;
    }

    this.converter.appendRawData(frame);
    return true;
  }

  // 停止转换器
  private stopConverter(): void {
    if (this.converter) {
      this.converter.appendRawData(new Uint8Array([]));
      this.converter.pause();
      delete this.converter;
    }
  }

  // 获取适应屏幕的状态
  public getFitToScreenStatus(): boolean {
    return MsePlayer.getFitToScreenStatus(this.udid, this.displayInfo);
  }

  // 加载视频设置
  public loadVideoSettings(): VideoSettings {
    return MsePlayer.loadVideoSettings(this.udid, this.displayInfo);
  }
}
