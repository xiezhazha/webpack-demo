export interface BaseDeviceDescriptor {
    udid: string;
    state: string;
}
