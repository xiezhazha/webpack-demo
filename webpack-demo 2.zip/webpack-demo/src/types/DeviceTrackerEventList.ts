export type DeviceTrackerEventList<T> = {
    name: string;
    id: string;
    list: T[];
};
