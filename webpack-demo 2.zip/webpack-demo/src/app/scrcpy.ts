import { StreamClientScrcpy } from "./googDevice/client/StreamClientScrcpy";
import { WebCodecsPlayer } from "./player/WebCodecsPlayer";
// import { MsePlayerForQVHack } from "./player/MsePlayerForQVHack";
import { KeyCodeControlMessage } from "./controlMessage/KeyCodeControlMessage";
import { MsePlayer } from "./player/MsePlayer";
import { TextControlMessage } from './controlMessage/TextControlMessage';
import { CommandControlMessage } from './controlMessage/CommandControlMessage';
import { ControlMessage } from './controlMessage/ControlMessage';
import { TouchControlMessage } from './controlMessage/TouchControlMessage';
import { StreamReceiver } from "./client/StreamReceiver";
import { ManagerClient } from "./client/ManagerClient";


export default {
  StreamClientScrcpy,
  WebCodecsPlayer,
  KeyCodeControlMessage,
  MsePlayer,
  TextControlMessage,
  CommandControlMessage,
  ControlMessage,
  TouchControlMessage,
  StreamReceiver,
  ManagerClient
};
